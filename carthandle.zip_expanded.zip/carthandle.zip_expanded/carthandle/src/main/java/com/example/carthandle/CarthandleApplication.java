package com.example.carthandle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarthandleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarthandleApplication.class, args);
	}

}
